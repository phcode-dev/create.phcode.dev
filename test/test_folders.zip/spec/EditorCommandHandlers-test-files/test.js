function testMe() {
    console.log("this is a test");
}

function main() {
    testMe();
}