/*global define, $ */

define(function (require, exports, module) {
    "use strict";

    exports.initExtension = function () {
        return new $.Deferred().resolve();
    };
});