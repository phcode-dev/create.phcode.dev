function notAnError() {
  "use strict";
}