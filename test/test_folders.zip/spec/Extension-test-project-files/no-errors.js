function foo() {
    "use strict";
    var body = document.body;
}