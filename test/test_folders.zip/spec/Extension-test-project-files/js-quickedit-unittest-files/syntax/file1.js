/*jslint vars: true, plusplus: true, devel: true, browser: true, nomen: true, indent: 4, maxerr: 50 */
/*global brackets, require */

var A1 = { propA : 1 },
    A2 = { propA : 2 },
    A3 = A2;
