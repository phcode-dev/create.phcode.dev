function edit1() {
    // this function starts at line 0, char 0
}

/*
 * simple functions
 */
var edit2 = function () {

};

edit3: function () {
    
}
    
/*
 * parameterized functions
 */
function edit4(p1) {
}

var edit5 = function (p1, p2) {

};

edit6: function (longParameterName1,
                  longParameterName2,
                  longParameterName3) {
    
}
    
