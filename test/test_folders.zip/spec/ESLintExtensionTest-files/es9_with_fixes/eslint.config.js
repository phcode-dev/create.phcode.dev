// eslint.config.js
export default [
    {
        rules: {
            semi: "error",
            "prefer-const": "error",
            eqeqeq: "warn",
            "no-trailing-spaces": "warn",
            "indent": [1, 4]
        }
    }
];
