console.log("hello", x==2)
