/*
 * GNU AGPL-3.0 License
 *
 * Copyright (c) 2021 - present core.ai . All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see https://opensource.org/licenses/AGPL-3.0.
 *
 */

/*global describe, beforeAll, afterAll, awaitsFor, awaits, it, awaitsForDone, expect*/

define(function (require, exports, module) {

    const SpecRunnerUtils = require("spec/SpecRunnerUtils");

    const mdTestFolder = SpecRunnerUtils.getTestPath("/spec/LiveDevelopment-Markdown-test-files");

    let testWindow, brackets, CommandManager, Commands, EditorManager, WorkspaceManager,
        LiveDevMultiBrowser;

    function _getMdPreviewIFrame() {
        return testWindow.document.getElementById("panel-md-preview-frame");
    }

    function _getMdIFrameDoc() {
        const mdIFrame = _getMdPreviewIFrame();
        return mdIFrame && mdIFrame.contentDocument;
    }

    function _getMdIFrameWin() {
        const mdIFrame = _getMdPreviewIFrame();
        return mdIFrame && mdIFrame.contentWindow;
    }

    async function _enterEditMode() {
        const win = _getMdIFrameWin();
        if (win && win.__setEditModeForTest) {
            win.__setEditModeForTest(false);
            win.__setEditModeForTest(true);
        }
        await awaitsFor(() => {
            const mdDoc = _getMdIFrameDoc();
            if (!mdDoc) { return false; }
            const content = mdDoc.getElementById("viewer-content");
            return content && content.classList.contains("editing");
        }, "edit mode to activate");
    }

    async function _enterReaderMode() {
        const win = _getMdIFrameWin();
        if (win && win.__setEditModeForTest) {
            win.__setEditModeForTest(false);
        }
        await awaitsFor(() => {
            const mdDoc = _getMdIFrameDoc();
            if (!mdDoc) { return false; }
            const content = mdDoc.getElementById("viewer-content");
            return content && !content.classList.contains("editing");
        }, "reader mode to activate");
    }

    async function _waitForMdPreviewReady(editor) {
        await awaitsFor(() => {
            const mdIFrame = _getMdPreviewIFrame();
            if (!mdIFrame || mdIFrame.style.display === "none") { return false; }
            if (!mdIFrame.src || !mdIFrame.src.includes("mdViewer")) { return false; }
            const win = mdIFrame.contentWindow;
            if (!win || typeof win.__setEditModeForTest !== "function") { return false; }
            if (win.__isSuppressingContentChange && win.__isSuppressingContentChange()) { return false; }
            const content = mdIFrame.contentDocument && mdIFrame.contentDocument.getElementById("viewer-content");
            if (!content || content.children.length === 0) { return false; }
            const activeEditor = EditorManager.getActiveEditor();
            if (!activeEditor) { return false; }
            // Re-read editor content each iteration — content sync from a previous
            // test's DOM edit can modify the document asynchronously (debounced postMessage).
            const expectedSrc = activeEditor.document.getText();
            if (expectedSrc) {
                const viewerSrc = win.__getCurrentContent && win.__getCurrentContent();
                if (viewerSrc !== expectedSrc) { return false; }
            }
            return true;
        }, "md preview synced with editor content", 5000);
    }

    function _dispatchKeyInMdIframe(key, options) {
        const mdDoc = _getMdIFrameDoc();
        if (!mdDoc) { return; }
        options = options || {};
        const mac = brackets.platform === "mac";
        const useMod = options.mod !== false;
        mdDoc.dispatchEvent(new KeyboardEvent("keydown", {
            key: key,
            code: options.code || ("Key" + key.toUpperCase()),
            keyCode: options.keyCode || key.toUpperCase().charCodeAt(0),
            which: options.keyCode || key.toUpperCase().charCodeAt(0),
            ctrlKey: mac ? false : useMod,
            metaKey: mac ? useMod : false,
            shiftKey: !!options.shiftKey,
            altKey: false,
            bubbles: true,
            cancelable: true
        }));
    }

    describe("livepreview:Markdown Editor Edit More", function () {

        if (Phoenix.browser.desktop.isFirefox ||
            (Phoenix.isTestWindowPlaywright && !Phoenix.browser.desktop.isChromeBased)) {
            it("Markdown edit more tests are disabled in Firefox/non-Chrome playwright", function () {});
            return;
        }

        beforeAll(async function () {
            if (!testWindow) {
                const useWindowInsteadOfIframe = Phoenix.browser.desktop.isFirefox;
                testWindow = await SpecRunnerUtils.createTestWindowAndRun({
                    forceReload: false, useWindowInsteadOfIframe
                });
                brackets = testWindow.brackets;
                CommandManager = brackets.test.CommandManager;
                Commands = brackets.test.Commands;
                EditorManager = brackets.test.EditorManager;
                WorkspaceManager = brackets.test.WorkspaceManager;
                LiveDevMultiBrowser = brackets.test.LiveDevMultiBrowser;

                await SpecRunnerUtils.loadProjectInTestWindow(mdTestFolder);
                await SpecRunnerUtils.deletePathAsync(mdTestFolder + "/.phcode.json", true);

                if (!WorkspaceManager.isPanelVisible("live-preview-panel")) {
                    await awaitsForDone(CommandManager.execute(Commands.FILE_LIVE_FILE_PREVIEW));
                }

                await awaitsForDone(SpecRunnerUtils.openProjectFiles(["simple.html"]),
                    "open simple.html");
                LiveDevMultiBrowser.open();
                await awaitsFor(() =>
                    LiveDevMultiBrowser.status === LiveDevMultiBrowser.STATUS_ACTIVE,
                "live dev to open", 20000);
            }
        }, 30000);

        afterAll(async function () {
            if (LiveDevMultiBrowser) {
                LiveDevMultiBrowser.close();
            }
            if (CommandManager) {
                await awaitsForDone(CommandManager.execute(Commands.FILE_CLOSE_ALL, { _forceClose: true }),
                    "final close all files");
            }
            testWindow = null;
            brackets = null;
            CommandManager = null;
            Commands = null;
            EditorManager = null;
            WorkspaceManager = null;
            LiveDevMultiBrowser = null;
        }, 30000);

        describe("In-Document Search (Ctrl+F)", function () {

            beforeAll(async function () {
                await awaitsForDone(SpecRunnerUtils.openProjectFiles(["doc1.md"]),
                    "open doc1.md");
                await _waitForMdPreviewReady(EditorManager.getActiveEditor());
                // Reset cache after iframe is ready (clears stale entries from prior suites)
                const win = _getMdIFrameWin();
                if (win && win.__resetCacheForTest) {
                    win.__resetCacheForTest();
                }
                // Re-open to get a fresh render after cache reset
                await awaitsForDone(SpecRunnerUtils.openProjectFiles(["simple.html"]),
                    "open simple.html to reset");
                await awaitsForDone(SpecRunnerUtils.openProjectFiles(["doc1.md"]),
                    "reopen doc1.md");
                await _waitForMdPreviewReady(EditorManager.getActiveEditor());
                await _enterEditMode();
            }, 20000);

            afterAll(async function () {
                await awaitsForDone(CommandManager.execute(Commands.FILE_CLOSE, { _forceClose: true }),
                    "force close doc1.md");
            });

            function _isSearchOpen() {
                const bar = _getMdIFrameDoc().getElementById("search-bar");
                return bar && bar.classList.contains("open");
            }

            function _getSearchCount() {
                return _getMdIFrameDoc().getElementById("search-count");
            }

            function _getHighlightedMatches() {
                return _getMdIFrameDoc().querySelectorAll("#viewer-content mark[data-markjs]");
            }

            function _getActiveMatch() {
                return _getMdIFrameDoc().querySelector("#viewer-content mark[data-markjs].active");
            }

            function _openSearchWithCtrlF() {
                _dispatchKeyInMdIframe("f");
            }

            function _openSearch() {
                if (brackets.platform === "mac") {
                    // Mac: use direct event emit to bypass nested iframe focus issues
                    const win = _getMdIFrameWin();
                    if (win && win.__toggleSearchForTest) {
                        win.__toggleSearchForTest();
                        return;
                    }
                }
                _openSearchWithCtrlF();
            }

            function _typeInSearch(text) {
                const input = _getMdIFrameDoc().getElementById("search-input");
                input.value = text;
                input.dispatchEvent(new Event("input", { bubbles: true }));
            }

            function _pressKeyInSearch(key, options) {
                const input = _getMdIFrameDoc().getElementById("search-input");
                input.dispatchEvent(new KeyboardEvent("keydown", {
                    key: key,
                    code: options && options.code || key,
                    shiftKey: !!(options && options.shiftKey),
                    bubbles: true,
                    cancelable: true
                }));
            }

            async function _closeSearch() {
                if (_isSearchOpen()) {
                    if (brackets.platform === "mac") {
                        // Mac: use toggle to avoid focus steal from Escape
                        const win = _getMdIFrameWin();
                        if (win && win.__toggleSearchForTest) {
                            win.__toggleSearchForTest();
                        } else {
                            _pressKeyInSearch("Escape");
                        }
                    } else {
                        _pressKeyInSearch("Escape");
                    }
                    await awaitsFor(() => !_isSearchOpen(), "search bar to close", 10000);
                }
            }

            // Shared search tests run in both edit and reader mode
            function execSearchTests(modeName, enterModeFn) {
                describe("Search in " + modeName + " mode", function () {

                    beforeAll(async function () {
                        await enterModeFn();
                    }, 30000);

                    it("should Ctrl+F open search bar", async function () {
                        expect(_isSearchOpen()).toBeFalse();
                        _openSearchWithCtrlF();
                        await awaitsFor(() => _isSearchOpen(), "search bar to open", 10000);
                        await _closeSearch();
                    }, 30000);

                    it("should typing in search highlight matches", async function () {
                        _openSearch();
                        await awaitsFor(() => _isSearchOpen(), "search bar to open", 10000);

                        _typeInSearch("Document");
                        await awaitsFor(() => _getHighlightedMatches().length > 0,
                            "matches to be highlighted", 10000);
                        expect(_getActiveMatch()).not.toBeNull();

                        await _closeSearch();
                    }, 30000);

                    it("should match count show N/total format", async function () {
                        _openSearch();
                        await awaitsFor(() => _isSearchOpen(), "search bar to open", 10000);

                        _typeInSearch("Document");
                        await awaitsFor(() => {
                            const count = _getSearchCount();
                            return count && /^\d+\/\d+$/.test(count.textContent);
                        }, "match count to show N/total format", 10000);

                        expect(_getSearchCount().textContent).toMatch(/^1\/\d+$/);
                        await _closeSearch();
                    }, 30000);

                    it("should Enter navigate to next match", async function () {
                        _openSearch();
                        await awaitsFor(() => _isSearchOpen(), "search bar to open", 10000);

                        _typeInSearch("Document");
                        await awaitsFor(() => _getHighlightedMatches().length > 0,
                            "matches to appear", 10000);

                        const firstActive = _getActiveMatch();
                        expect(firstActive).not.toBeNull();

                        _pressKeyInSearch("Enter");
                        await awaitsFor(() => {
                            const active = _getActiveMatch();
                            return active && active !== firstActive;
                        }, "active match to change on Enter", 10000);

                        await _closeSearch();
                    }, 30000);

                    it("should Shift+Enter navigate to previous match", async function () {
                        _openSearch();
                        await awaitsFor(() => _isSearchOpen(), "search bar to open", 10000);

                        _typeInSearch("Document");
                        await awaitsFor(() => _getHighlightedMatches().length > 0,
                            "matches to appear", 10000);

                        _pressKeyInSearch("Enter");
                        await awaitsFor(() => {
                            const count = _getSearchCount();
                            return count && count.textContent.startsWith("2/");
                        }, "to be on match 2", 10000);

                        _pressKeyInSearch("Enter", { shiftKey: true });
                        await awaitsFor(() => {
                            const count = _getSearchCount();
                            return count && count.textContent.startsWith("1/");
                        }, "to navigate back to match 1", 10000);

                        await _closeSearch();
                    }, 30000);

                    it("should navigation wrap around", async function () {
                        _openSearch();
                        await awaitsFor(() => _isSearchOpen(), "search bar to open", 10000);

                        _typeInSearch("Document");
                        await awaitsFor(() => _getHighlightedMatches().length > 0,
                            "matches to appear", 10000);

                        const totalMatches = _getHighlightedMatches().length;
                        for (let i = 0; i < totalMatches - 1; i++) {
                            _pressKeyInSearch("Enter");
                        }
                        await awaitsFor(() => {
                            const count = _getSearchCount();
                            return count && count.textContent.startsWith(totalMatches + "/");
                        }, "to be on last match", 10000);

                        _pressKeyInSearch("Enter");
                        await awaitsFor(() => {
                            const count = _getSearchCount();
                            return count && count.textContent.startsWith("1/");
                        }, "to wrap to first match", 10000);

                        await _closeSearch();
                    }, 30000);

                    it("should Escape close search and restore focus", async function () {
                        _openSearch();
                        await awaitsFor(() => _isSearchOpen(), "search bar to open", 10000);

                        _typeInSearch("test");
                        await awaitsFor(() => _getHighlightedMatches().length > 0,
                            "matches to appear", 10000);

                        _pressKeyInSearch("Escape");
                        await awaitsFor(() => !_isSearchOpen(), "search bar to close", 10000);

                        // Focus should leave the search input
                        const mdDoc = _getMdIFrameDoc();
                        const searchInput = mdDoc.getElementById("search-input");
                        await awaitsFor(() => {
                            return mdDoc.activeElement !== searchInput;
                        }, "focus to leave search input");
                    }, 30000);

                    it("should closing search clear all highlights", async function () {
                        _openSearch();
                        await awaitsFor(() => _isSearchOpen(), "search bar to open", 10000);

                        _typeInSearch("Document");
                        await awaitsFor(() => _getHighlightedMatches().length > 0,
                            "matches to appear", 10000);

                        await _closeSearch();
                        expect(_getHighlightedMatches().length).toBe(0);
                    }, 30000);

                    it("should close button close search", async function () {
                        _openSearch();
                        await awaitsFor(() => _isSearchOpen(), "search bar to open", 10000);

                        _typeInSearch("test");
                        await awaitsFor(() => _getHighlightedMatches().length > 0,
                            "matches to appear", 10000);

                        _getMdIFrameDoc().getElementById("search-close").click();
                        await awaitsFor(() => !_isSearchOpen(), "search bar to close via × button", 10000);
                        expect(_getHighlightedMatches().length).toBe(0);
                    }, 30000);

                    it("should search start from 1 character", async function () {
                        _openSearch();
                        await awaitsFor(() => _isSearchOpen(), "search bar to open", 10000);

                        _typeInSearch("D");
                        await awaitsFor(() => _getHighlightedMatches().length > 0,
                            "matches to appear for single character");

                        await _closeSearch();
                    }, 30000);

                    it("should Escape in search NOT forward to Phoenix", async function () {
                        _openSearch();
                        await awaitsFor(() => _isSearchOpen(), "search bar to open", 10000);

                        let escapeSent = false;
                        const handler = function (event) {
                            if (event.data && event.data.type === "MDVIEWR_EVENT" &&
                                event.data.eventName === "embeddedEscapeKeyPressed") {
                                escapeSent = true;
                            }
                        };
                        testWindow.addEventListener("message", handler);

                        _pressKeyInSearch("Escape");
                        await awaitsFor(() => !_isSearchOpen(), "search bar to close", 10000);

                        testWindow.removeEventListener("message", handler);
                        expect(escapeSent).toBeFalse();
                    }, 30000);
                });
            }

            // Run all search tests in both modes
            execSearchTests("edit", _enterEditMode);
            execSearchTests("reader", _enterReaderMode);
        });

        describe("Non-markdown file preview behavior", function () {

            function _getMdPreviewH1() {
                const mdDoc = _getMdIFrameDoc();
                if (!mdDoc) { return null; }
                const h1 = mdDoc.querySelector("#viewer-content h1");
                return h1 ? h1.textContent : null;
            }

            it("should not render binary/json files in md viewer when switching from md", async function () {
                // Open a markdown file first
                await awaitsForDone(SpecRunnerUtils.openProjectFiles(["doc1.md"]),
                    "open doc1.md");
                await _waitForMdPreviewReady(EditorManager.getActiveEditor());

                // Remember what the md viewer is showing
                const mdH1Before = _getMdPreviewH1();
                expect(mdH1Before).not.toBeNull();

                // Switch to a JSON file (non-markdown, non-previewable)
                await awaitsForDone(SpecRunnerUtils.openProjectFiles(["test-data.json"]),
                    "open test-data.json");
                // Negative assertion: wait for any async switch to settle
                await awaits(500);

                // The md viewer should still show the last md file's content,
                // NOT the json file's content
                const mdH1After = _getMdPreviewH1();
                expect(mdH1After).toBe(mdH1Before);

                // The md viewer content should NOT contain json data
                const mdDoc = _getMdIFrameDoc();
                const viewerText = mdDoc.getElementById("viewer-content").textContent;
                expect(viewerText).not.toContain('"name"');
                expect(viewerText).not.toContain('"value"');

                await awaitsForDone(CommandManager.execute(Commands.FILE_CLOSE, { _forceClose: true }),
                    "force close test-data.json");
            }, 15000);

            it("should resume md preview when switching back to md from non-md file", async function () {
                // Open doc1.md
                await awaitsForDone(SpecRunnerUtils.openProjectFiles(["doc1.md"]),
                    "open doc1.md");
                await _waitForMdPreviewReady(EditorManager.getActiveEditor());
                const doc1H1 = _getMdPreviewH1();

                // Switch to JSON
                await awaitsForDone(SpecRunnerUtils.openProjectFiles(["test-data.json"]),
                    "open test-data.json");
                await awaits(500);

                // Switch to doc2.md — should show doc2 content, not doc1 or json
                await awaitsForDone(SpecRunnerUtils.openProjectFiles(["doc2.md"]),
                    "open doc2.md");
                await _waitForMdPreviewReady(EditorManager.getActiveEditor());

                const doc2H1 = _getMdPreviewH1();
                expect(doc2H1).not.toBeNull();
                expect(doc2H1).not.toBe(doc1H1);

                await awaitsForDone(CommandManager.execute(Commands.FILE_CLOSE, { _forceClose: true }),
                    "force close doc2.md");
            }, 15000);

            it("should keep last md preview when switching to HTML file", async function () {
                // Open a markdown file
                await awaitsForDone(SpecRunnerUtils.openProjectFiles(["doc1.md"]),
                    "open doc1.md");
                await _waitForMdPreviewReady(EditorManager.getActiveEditor());
                const mdH1 = _getMdPreviewH1();

                // Switch to HTML — live preview should switch to HTML, hiding md viewer
                await awaitsForDone(SpecRunnerUtils.openProjectFiles(["simple.html"]),
                    "open simple.html");
                await awaits(500);

                // MD iframe should be hidden (HTML live preview takes over)
                const mdIFrame = _getMdPreviewIFrame();
                const mdHidden = !mdIFrame || mdIFrame.style.display === "none";
                // OR if md viewer stayed visible, its content should be the last md file
                if (!mdHidden) {
                    expect(_getMdPreviewH1()).toBe(mdH1);
                }

                await awaitsForDone(CommandManager.execute(Commands.FILE_CLOSE, { _forceClose: true }),
                    "force close simple.html");
            }, 15000);
        });
    });
});
