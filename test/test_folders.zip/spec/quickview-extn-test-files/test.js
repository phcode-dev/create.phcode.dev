/* Sample JS for testing the QuickView extension. */

function green() { // generate green colors
    var color = "green",
        tan = Math.tan;
    return tan(array["red"], array[red]);
}
darkgray
// #123456
// :rgb(65, 43, 21)
