<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <?php echo '<p>Hello World</p>'; ?>
    </head>
    <body>
        <div class="clouds">
            <i>
                <?php echo '<p>Hello World</p>'; ?>
                <span><u>spanning</u></span>
            </i>
        </div>
        <div class="clouds">
            <b class="someth" style="display: flex"> <span>hello world</span></b>
            <a
               href="a.html">click
            </a
                >
        </div>
        <div attr="test"></div>
    </body>
</html>
