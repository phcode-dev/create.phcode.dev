/*
 * GNU AGPL-3.0 License
 *
 * Copyright (c) 2021 - present core.ai . All rights reserved.
 * Original work Copyright (c) 2014 - 2021 Adobe Systems Incorporated. All rights reserved.
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see https://opensource.org/licenses/AGPL-3.0.
 *
 */

/*global describe, it, expect, beforeEach, afterEach, awaitsFor, awaitsForDone, beforeAll, afterAll, awaits, path */

define(function (require, exports, module) {


    var CommandManager,         // Load from brackets.test
        Commands,               // Load from brackets.test
        DocumentManager,        // Load from brackets.test
        FileViewController,     // Load from brackets.test
        MainViewManager,        // Load from brackets.test
        ProjectManager,         // Load from brackets.test
        WorkingSetView,
        SpecRunnerUtils         = require("spec/SpecRunnerUtils");


    describe("mainview:WorkingSetView", function () {

        var testPath = SpecRunnerUtils.getTestPath("/spec/WorkingSetView-test-files"),
            externalProjectTestPath = SpecRunnerUtils.getTestPath("/spec/MainViewFactory-test-files/css"),
            testWindow,
            workingSetListItemCount;

        async function openAndMakeDirty(path) {
            var doc, didOpen = false, gotError = false;

            // open file
            FileViewController.openAndSelectDocument(path, FileViewController.PROJECT_MANAGER)
                .done(function () { didOpen = true; })
                .fail(function () { gotError = true; });
            await awaitsFor(function () { return didOpen && !gotError; },
                "FILE_OPEN on file timeout");

            // change editor content to make doc dirty which adds it to the working set
            doc = DocumentManager.getCurrentDocument();
            doc.setText("dirty document");
        }

        async function createTestWindow(spec, loadProject) {
            testWindow = await SpecRunnerUtils.createTestWindowAndRun();
            // Load module instances from brackets.test
            CommandManager      = testWindow.brackets.test.CommandManager;
            Commands            = testWindow.brackets.test.Commands;
            DocumentManager     = testWindow.brackets.test.DocumentManager;
            FileViewController  = testWindow.brackets.test.FileViewController;
            MainViewManager     = testWindow.brackets.test.MainViewManager;
            WorkingSetView      = testWindow.brackets.test.WorkingSetView;
            ProjectManager      = testWindow.brackets.test.ProjectManager;

            // Open a directory
            if (loadProject) {
                await SpecRunnerUtils.loadProjectInTestWindow(testPath);
            }

            // Initialize: register listeners
            MainViewManager.on("workingSetAdd", function (event, addedFile) {
                workingSetListItemCount++;
            });
        }

        async function closeTestWindow() {
            testWindow          = null;
            CommandManager      = null;
            Commands            = null;
            DocumentManager     = null;
            FileViewController  = null;
            MainViewManager     = null;
            await SpecRunnerUtils.closeTestWindow();
        }

        beforeAll(async function () {
            await createTestWindow(this, true);
        }, 30000);

        afterAll(async function () {
            await closeTestWindow();
        }, 30000);

        beforeEach(async function () {
            workingSetListItemCount = 0;

            await openAndMakeDirty(testPath + "/file_one.js");
            await openAndMakeDirty(testPath + "/file_two.js");

            // Wait for both files to be added to the working set
            await awaitsFor(function () { return workingSetListItemCount === 2; }, "workingSetListItemCount to equal 2");
        });

        afterEach(async function () {
            // restore state in case a selection marker test failed midway
            testWindow.brackets.test.PreferencesManager.set("showWorkingSet", true);
            const SidebarTabs = testWindow.brackets.test.SidebarTabs;
            SidebarTabs.setActiveTab(SidebarTabs.SIDEBAR_TAB_FILES);
            testWindow.$(".open-files-container").css("height", "");
            await testWindow.closeAllFiles();
        });

        it("should add a list item when a file is dirtied", function () {
            // check if files are added to work set and dirty icons are present
            var $listItems = testWindow.$(".open-files-container > ul").children();
            expect($listItems.length).toBe(2);
            expect($listItems.find("a").get(0).text === "file_one.js").toBeTruthy();
            expect($listItems.find(".file-status-icon").length).toBe(2);
        });

        it("should remove a list item when a file is closed", async function () {
            DocumentManager.getCurrentDocument()._markClean(); // so we can close without a save dialog

            // close the document
            var didClose = false, gotError = false;
            CommandManager.execute(Commands.FILE_CLOSE)
                .done(function () { didClose = true; })
                .fail(function () { gotError = true; });
            await awaitsFor(function () { return didClose && !gotError; }, "FILE_OPEN on file timeout");

            // check there are no list items
            var listItems = testWindow.$(".open-files-container > ul").children();
            expect(listItems.length).toBe(1);
        });

        it("should make a file that is clicked the current one in the editor", function () {
            var $ = testWindow.$;
            var secondItem =  $($(".open-files-container > ul").children()[1]);
            secondItem.trigger("click");

            var $listItems = $(".open-files-container > ul").children();
            expect($($listItems[0]).hasClass("selected")).not.toBeTruthy();
            expect($($listItems[1]).hasClass("selected")).toBeTruthy();
        });

        it("should close a file when the user clicks the close button", async function () {
            var $ = testWindow.$;
            var didClose = false;

            // make 2nd doc clean
            var fileList = MainViewManager.getWorkingSet(MainViewManager.ACTIVE_PANE);

            var doc0 = DocumentManager.getOpenDocumentForPath(fileList[0].fullPath);
            var doc1 = DocumentManager.getOpenDocumentForPath(fileList[1].fullPath);
            doc1._markClean();

            // make the first one active
            MainViewManager._edit(MainViewManager.ACTIVE_PANE, doc0);

            // hover over and click on close icon of 2nd list item
            var secondItem =  $($(".open-files-container > ul").children()[1]);
            secondItem.trigger("mouseover");
            var closeIcon = secondItem.find(".file-status-icon");
            expect(closeIcon.length).toBe(1);

            // simulate click
            MainViewManager.on("workingSetRemove", function (event, removedFile) {
                didClose = true;
            });

            closeIcon.trigger("mousedown");

            await awaitsFor(function () { return didClose; }, "click on working set close icon timeout");

            var $listItems = $(".open-files-container > ul").children();
            expect($listItems.length).toBe(1);
            expect($listItems.find("a").get(0).text === "file_one.js").toBeTruthy();
        });

        it("should remove dirty icon when file becomes clean", async function () {
            // check that dirty icon is removed when docs are cleaned
            var fileList = MainViewManager.getWorkingSet(MainViewManager.ACTIVE_PANE);
            var doc0 = DocumentManager.getOpenDocumentForPath(fileList[0].fullPath);
            doc0._markClean();

            var listItems = testWindow.$(".open-files-container > ul").children();
            expect(listItems.find(".file-status-icon dirty").length).toBe(0);
        });

        it("should show the file in project tree when a file is being renamed", async function () {
            var $ = testWindow.$;
            var secondItem =  $(".open-files-container > ul").children().eq(1);
            var fileName = secondItem.text();

            secondItem.trigger("click");

            // Calling FILE_RENAME synchronously works fine here since the item is already visible in project file tree.
            // However, if the selected item is not already visible in the tree, this command will complete asynchronously.
            // In that case, await awaitsFor will be needed before continuing with the rest of the test.
            CommandManager.execute(Commands.FILE_RENAME);

            await awaits(ProjectManager._RENDER_DEBOUNCE_TIME + 50);

            await awaitsFor(function () {
                return $("#project-files-container ul input").val() === fileName;
            });
        });

        it("should show a directory name next to the file name when two files with same names are opened", async function () {
            // Count currently opened files
            var workingSetListItemCountBeforeTest = workingSetListItemCount;

            // First we need to open another file
            await openAndMakeDirty(testPath + "/directory/file_one.js");

            // Wait for file to be added to the working set
            await awaitsFor(function () { return workingSetListItemCount === workingSetListItemCountBeforeTest + 1; });

            // Two files with the same name file_one.js should be now opened
            var $list = testWindow.$(".open-files-container > ul");
            expect($list.find(".directory").length).toBe(2);

            // Now close last opened file to hide the directories again
            DocumentManager.getCurrentDocument()._markClean(); // so we can close without a save dialog
            await awaitsForDone(CommandManager.execute(Commands.FILE_CLOSE), "timeout on FILE_CLOSE", 1000);

            // there should be no more directories shown
            expect($list.find(".directory").length).toBe(0);
        });

        it("should show ellipsis on external project files", async function () {
            // empty the working set
            await testWindow.closeAllFiles();
            workingSetListItemCount = 0;
            const virtualPath = externalProjectTestPath + "/tablet.css";
            const hoverFullPath = Phoenix.app.getDisplayPath(virtualPath);

            let sep;
            if (Phoenix.isNativeApp && brackets.platform === "win") {
                sep =  "\\";
            } else {
                sep = "/";
            }
            let dirSplit = Phoenix.app.getDisplayPath(virtualPath).split(sep).filter(segment => segment !== '');
            const root = dirSplit[0];

            await openAndMakeDirty(virtualPath);

            // wait for the file to add to the working set
            await awaitsFor(function () { return workingSetListItemCount === 1; }, "Open file count to be 1");

            // get the directory path
            var $list = testWindow.$(".open-files-container > ul");
            const directorySpan = $list.find(".directory");
            expect(directorySpan.length).toBe(1);

            // get the text from the directory path
            const directoryText = directorySpan[0].innerHTML;

            // check if the directory path has ellipsis
            expect(directoryText.includes("\u2026")).toBe(true);
            if (!Phoenix.isNativeApp) {
                expect(directoryText).toBe(' — /test/…/MainViewFactory-test-files/css');
            } else if (brackets.platform === "linux" || brackets.platform === "mac") {
                expect(directoryText).toBe(` — /${root}/…/MainViewFactory-test-files/css`);
            } else {
                // windows
                expect(directoryText).toBe(` — ${root}\\…\\MainViewFactory-test-files\\css`);
            }

            // the title should contain the full path
            expect(directorySpan.attr('title')).toBe(hoverFullPath);

            // Clean up
            DocumentManager.getCurrentDocument()._markClean(); // so we can close without a save dialog
            await awaitsForDone(CommandManager.execute(Commands.FILE_CLOSE), "timeout on FILE_CLOSE", 1000);
        });

        it("should show different directory names, when two files of the same name are opened, located in folders with same name", async function () {
            // Count currently opened files
            var workingSetListItemCountBeforeTest = workingSetListItemCount;

            // Open both files
            await openAndMakeDirty(testPath + "/directory/file_one.js");
            await openAndMakeDirty(testPath + "/directory/directory/file_one.js");

            // Wait for them to load
            await awaitsFor(function () { return workingSetListItemCount === workingSetListItemCountBeforeTest + 2; }, "Open file count to be increased by 2");

            // Collect all directory names displayed
            var $list = testWindow.$(".open-files-container > ul");
            var names = $list.find(".directory").map(function () {
                return $(this).text();
            }).toArray();

            // All directory names should be unique
            var uniq = 0, map = {};
            names.forEach(function (name) {
                if (!map[name]) {
                    map[name] = true;
                    uniq++;
                }
            });
            expect(uniq).toBe(names.length);
        });

        it("should callback for icons", async function () {
            function iconProvider(file) {
                return "<img src='" + file.name + ".jpg' class='icon' />";
            }

            WorkingSetView.addIconProvider(iconProvider);

            // Collect all icon filenames used
            var $list = testWindow.$(".open-files-container > ul");
            var icons = $list.find(".icon").map(function () {
                return $(this).attr("src");
            }).toArray();

            // All directory names should be unique
            expect(icons.length).toBe(2);
            expect(icons[0]).toBe("file_one.js.jpg");
            expect(icons[1]).toBe("file_two.js.jpg");
        });

        it("should callback for class", async function () {
            var master = ["one", "two"],
                classes = master.slice(0);

            function classProvider(file) {
                return classes.pop();
            }

            WorkingSetView.addClassProvider(classProvider);

            var $list = testWindow.$(".open-files-container > li"),
                test = master.slice(0);

            $list.each(function (number, el) {
                expect($(el).hasClass(test.pop())).toBeTruthy();
            });
        });

        function _isMarkerAlignedWithSelection() {
            const $ = testWindow.$;
            const $selected = $(".open-files-container li.selected");
            const $marker = $(".open-files-container .sidebar-selection");
            return $selected.length === 1 && $marker.length === 1 &&
                Math.abs($marker.offset().top - $selected.offset().top) < 2;
        }

        it("should reposition selection marker and reveal selection when working set is shown again", async function () {
            const $ = testWindow.$;
            const PreferencesManager = testWindow.brackets.test.PreferencesManager;
            const fileList = MainViewManager.getWorkingSet(MainViewManager.ACTIVE_PANE);
            const $container = $(".open-files-container");

            // view the first file
            await awaitsForDone(CommandManager.execute(Commands.FILE_OPEN, { fullPath: fileList[0].fullPath }),
                "FILE_OPEN first file");

            // shrink the list so the second item overflows and must be scrolled to
            $container.css("height", "30px");
            $container.scrollTop(0);

            // hide the working set
            PreferencesManager.set("showWorkingSet", false);
            await awaitsFor(function () {
                return $("#working-set-list-container").hasClass("working-set-hidden");
            }, "working set to hide");

            // switch to the second file while hidden - marker offsets all compute
            // to 0 on display:none elements, so it cannot be positioned now
            await awaitsForDone(CommandManager.execute(Commands.FILE_OPEN, { fullPath: fileList[1].fullPath }),
                "FILE_OPEN second file");

            // show the working set again
            PreferencesManager.set("showWorkingSet", true);
            await awaitsFor(function () {
                return !$("#working-set-list-container").hasClass("working-set-hidden");
            }, "working set to show");

            // the marker must align with the newly selected item and the item
            // must be scrolled into view
            await awaitsFor(_isMarkerAlignedWithSelection, "selection marker to align with selected item");
            await awaitsFor(function () {
                const $selected = $(".open-files-container li.selected");
                const containerTop = $container.offset().top;
                const containerBottom = containerTop + $container.height();
                return $selected.offset().top >= containerTop &&
                    ($selected.offset().top + $selected.height()) <= containerBottom;
            }, "selected item to be scrolled into view");
        });

        it("should reposition selection marker when switching back to the files sidebar tab", async function () {
            const $ = testWindow.$;
            const SidebarTabs = testWindow.brackets.test.SidebarTabs;
            const fileList = MainViewManager.getWorkingSet(MainViewManager.ACTIVE_PANE);
            const TEST_TAB = "sidebar-tab-wsv-selection-test";

            // view the first file
            await awaitsForDone(CommandManager.execute(Commands.FILE_OPEN, { fullPath: fileList[0].fullPath }),
                "FILE_OPEN first file");

            // switch to another sidebar tab, which hides the files tab content
            SidebarTabs.addTab(TEST_TAB, "wsv test", "fa-solid fa-flask");
            SidebarTabs.setActiveTab(TEST_TAB);
            await awaitsFor(function () {
                return !$("#working-set-list-container").is(":visible");
            }, "working set to be hidden by tab switch");

            // switch to the second file while the files tab content is hidden
            await awaitsForDone(CommandManager.execute(Commands.FILE_OPEN, { fullPath: fileList[1].fullPath }),
                "FILE_OPEN second file");

            // switch back to the files tab
            SidebarTabs.setActiveTab(SidebarTabs.SIDEBAR_TAB_FILES);
            await awaitsFor(function () {
                return $("#working-set-list-container").is(":visible");
            }, "working set to be visible again");

            await awaitsFor(_isMarkerAlignedWithSelection, "selection marker to align with selected item");

            SidebarTabs.removeTab(TEST_TAB);
        });

        it("should allow refresh to be used to update the class list", async function () {
            function classProvider(file) {
                return "one";
            }

            WorkingSetView.addClassProvider(classProvider);

            var master = ["three", "four"];

            WorkingSetView.refresh();

            var $list = testWindow.$(".open-files-container > li"),
                test = master.slice(0);

            $list.each(function (number, el) {
                expect($(el).hasClass(test.pop())).toBeTruthy();
                expect($(el).hasClass("one")).toBeFalsy();
            });
        });
    });
});
