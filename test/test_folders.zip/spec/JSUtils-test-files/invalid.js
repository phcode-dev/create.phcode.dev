function 0digitIdentifierStart () {
}

function .punctuationIdentifierStart () {
}

function punctuation.IdentifierPart () {
}
