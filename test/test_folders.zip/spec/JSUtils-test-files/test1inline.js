{{0}}function func1() {
    // comment
}

/*
 * comment
 */
{{1}}var func2 = function() {

{{2}}    func3: function() {
        /* comment */
    }

}

function func4() {
    return func1();
}

function func5() {
    return true;
}
