
/*jslint vars: true, plusplus: true, devel: true, browser: true, nomen: true, indent: 4, maxerr: 50 */
/*global func1: false, func2: false, func3: false */

var a = {{0}}func1();
var b = fun{{1}}c2();
var c = func3{{2}}();
