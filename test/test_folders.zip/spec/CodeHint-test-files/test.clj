(defn square [x]
  (* x x))
