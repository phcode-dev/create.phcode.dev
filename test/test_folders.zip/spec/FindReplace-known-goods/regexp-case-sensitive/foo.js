/* Test comment */
define(function (require, exports, module) {
    CHANGED Foo = require("modules/Foo"),
        Bar = require("modules/Bar"),
        Baz = require("modules/Baz");
    
    function callFoo() {
        
        CHANGED();
        
    }

}
